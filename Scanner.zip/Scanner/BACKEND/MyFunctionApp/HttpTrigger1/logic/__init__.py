# Logic module for Azure Function App
