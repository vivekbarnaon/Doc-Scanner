import React from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import {
  AppBar,
  Toolbar,
  Typography,
  Box,
  Button,
} from '@mui/material';
import {
  Home,
  AutoAwesome,
  History,
} from '@mui/icons-material';

const Header: React.FC = () => {
  const navigate = useNavigate();
  const location = useLocation();

  const handleLogoClick = () => {
    navigate('/');
  };

  const handleFeaturesClick = () => {
    navigate('/features');
  };

  const handleHistoryClick = () => {
    navigate('/history');
  };

  return (
    <AppBar
      position="fixed"
      sx={{
        background: 'rgba(255, 255, 255, 0.1)',
        backdropFilter: 'blur(15px)',
        boxShadow: '0 8px 32px rgba(0, 0, 0, 0.1)',
        border: '1px solid rgba(255, 255, 255, 0.2)',
        borderBottom: '1px solid rgba(255, 255, 255, 0.3)',
        zIndex: 1100,
      }}
    >
      <Toolbar sx={{ minHeight: '70px !important' }}>
        <Box sx={{ display: 'flex', alignItems: 'center', flexGrow: 1 }}>
          <Typography
            variant="h4"
            component="div"
            onClick={handleLogoClick}
            sx={{
              fontWeight: 900,
              background: 'linear-gradient(45deg, #667eea 0%, #764ba2 50%, #f093fb 100%)',
              backgroundClip: 'text',
              WebkitBackgroundClip: 'text',
              WebkitTextFillColor: 'transparent',
              fontSize: '1.8rem',
              letterSpacing: '-0.5px',
              fontFamily: '"Inter", "Roboto", sans-serif',
              cursor: 'pointer',
              mr: 3,
              transition: 'all 0.3s ease',
              '&:hover': {
                transform: 'scale(1.05)',
                filter: 'brightness(1.2)',
              },
            }}
          >
            DocScan
          </Typography>

          {/* Navigation Buttons */}
          <Box sx={{ display: 'flex', gap: 2 }}>
            <Button
              onClick={handleLogoClick}
              startIcon={<Home />}
              sx={{
                color: 'white',
                textTransform: 'none',
                fontWeight: 600,
                borderRadius: '12px',
                padding: '8px 16px',
                backgroundColor: location.pathname === '/' ? 'rgba(255, 255, 255, 0.2)' : 'transparent',
                '&:hover': {
                  backgroundColor: 'rgba(255, 255, 255, 0.2)',
                },
              }}
            >
              Home
            </Button>
            <Button
              onClick={handleFeaturesClick}
              startIcon={<AutoAwesome />}
              sx={{
                color: 'white',
                textTransform: 'none',
                fontWeight: 600,
                borderRadius: '12px',
                padding: '8px 16px',
                backgroundColor: location.pathname === '/features' ? 'rgba(255, 255, 255, 0.2)' : 'transparent',
                '&:hover': {
                  backgroundColor: 'rgba(255, 255, 255, 0.2)',
                },
              }}
            >
              Features
            </Button>
            <Button
              onClick={handleHistoryClick}
              startIcon={<History />}
              sx={{
                color: 'white',
                textTransform: 'none',
                fontWeight: 600,
                borderRadius: '12px',
                padding: '8px 16px',
                backgroundColor: location.pathname === '/history' ? 'rgba(255, 255, 255, 0.2)' : 'transparent',
                '&:hover': {
                  backgroundColor: 'rgba(255, 255, 255, 0.2)',
                },
              }}
            >
              History
            </Button>
          </Box>
        </Box>
      </Toolbar>
    </AppBar>
  );
};

export default Header;
